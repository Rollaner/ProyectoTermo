package com.example.caloriecountxml

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.caloriecountxml.databinding.ActivityMainBinding

class MATimePicker : AppCompatActivity() {

    //Seba, puse de nuevo el viewBinding para que el programa funcione, recuerda que en el discord
    //dejé una foto para colocarlo en el build.gradle.app, pero dejo a tu criterio si lo ves
    //necesario dejar el viewBinding o sacarlo al ponerlo en la aplicación

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        setContentView(R.layout.activity_main)


        //botón que conecta con la función showTimePickerDialog
        //binding.buttonSecond.setOnClickListener { showTimePickerDialog() }


    }

    private fun showTimePickerDialog() {
        val timePicker = TimePickerFragment { onTimeSelected(it) }
        timePicker.show(supportFragmentManager, "time")
    }

    private fun onTimeSelected(time: String) {
        //El texto que se muestra al seleccionar la hora
        // Text(text = "Ha seleccionado las $time")

    }
}
