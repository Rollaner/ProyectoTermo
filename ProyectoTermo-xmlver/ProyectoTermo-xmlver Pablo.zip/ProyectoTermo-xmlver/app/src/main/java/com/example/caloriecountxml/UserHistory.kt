package com.example.caloriecountxml

import java.util.Calendar

//calendario e historial calorias
//solo maneja la UI y recoleccion de datos, no guarda nada

class UserHistory {

}